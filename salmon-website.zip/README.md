# Salmon Website 🐟

Simple salmon-themed website project.

## Features
- Clean UI
- Salmon color theme
- Basic JavaScript interaction

## How to Run
Just open `index.html` in your browser.

## Author
Your Name
