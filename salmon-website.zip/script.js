function showMessage() {
    alert("Salmon is awesome! 🐟");
}
